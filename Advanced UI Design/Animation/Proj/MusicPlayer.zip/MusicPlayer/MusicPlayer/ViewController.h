//
//  ViewController.h
//  MusicPlayer
//
//  Created by Ray on 03/07/2017.
//  Copyright © 2017 com.netease.homework. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

