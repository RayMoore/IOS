//
//  AppDelegate.h
//  NTESTouch1Demo
//
//  Created by jeunfung on 16/7/26.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

