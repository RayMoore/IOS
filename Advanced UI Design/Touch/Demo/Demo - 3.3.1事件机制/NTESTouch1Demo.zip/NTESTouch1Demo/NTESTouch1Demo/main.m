//
//  main.m
//  NTESTouch1Demo
//
//  Created by jeunfung on 16/7/26.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "TestApplication.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, NSStringFromClass([TestApplication class]), NSStringFromClass([AppDelegate class]));
    }
}
