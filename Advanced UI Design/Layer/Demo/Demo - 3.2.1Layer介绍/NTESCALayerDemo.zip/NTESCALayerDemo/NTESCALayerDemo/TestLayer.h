//
//  TestLayer.h
//  NTESCALayerDemo
//
//  Created by lujunfeng on 16/7/11.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface TestLayer : CALayer

@end
