//
//  TestLayer.m
//  NTESCALayerDemo
//
//  Created by lujunfeng on 16/7/11.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import "TestLayer.h"

@implementation TestLayer

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

@end
