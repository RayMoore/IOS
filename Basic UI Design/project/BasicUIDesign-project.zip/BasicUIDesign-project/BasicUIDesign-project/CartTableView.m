//
//  CartTableView.m
//  BasicUIDesign-project
//
//  Created by Ray on 08/06/2017.
//  Copyright © 2017 com.netease.homework. All rights reserved.
//

#import "CartTableView.h"
#import "CartTableViewCell.h"
#import "CartSectionView.h"
#import "Item.h"
#import "Factory.h"

@interface CartTableView()

@end

@implementation CartTableView


-(instancetype)initWithData:(NSMutableSet *)dataSet{
    self = [super init];
    return self;
}




@end
