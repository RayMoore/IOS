//
//  CheckoutChangeObserver.h
//  BasicUIDesign-project
//
//  Created by Ray on 18/06/2017.
//  Copyright © 2017 com.netease.homework. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CartMainViewController.h"

@interface CheckoutPriceChangeObserver : NSObject

-(instancetype)initWithController:(CartMainViewController*)controller;

@end
