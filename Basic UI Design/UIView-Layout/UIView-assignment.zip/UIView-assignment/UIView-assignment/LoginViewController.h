//
//  LoginViewController.h
//  UIView-assignment
//
//  Created by Ray on 04/06/2017.
//  Copyright © 2017 com.netease.homework. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController

@end
