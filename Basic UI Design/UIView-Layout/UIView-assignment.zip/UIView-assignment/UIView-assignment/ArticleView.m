//
//  ArticleView.m
//  UIView-assignment
//
//  Created by Ray on 04/06/2017.
//  Copyright © 2017 com.netease.homework. All rights reserved.
//

#import "ArticleView.h"

@implementation ArticleView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
